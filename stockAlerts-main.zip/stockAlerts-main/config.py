# config.py

# API keys
TWELVE_DATA_API_KEY = '340bb996905940fa9a893be5a1142083'
FINNHUB_API_KEY = 'cpi2l71r01qjh6bi0gkgcpi2l71r01qjh6bi0gl0'
SENDGRID_API_KEY = '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'

# Email settings
SENDGRID_FROM_EMAIL = 'apostolis.vrodos@gmail.com'
SENDGRID_RECIPIENTS = ['apostolis.vrodos@gmail.com','thanasisvrodos@gmail.com']